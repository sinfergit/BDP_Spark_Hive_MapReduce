package airbnb;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;

import java.io.IOException;

public class RentalsForNeighbourhoodGroup {

    public static class RentalsGroupMapper extends Mapper<LongWritable, Text, Text, IntWritable> {

        Text mapperText = new Text();
        private final static IntWritable one = new IntWritable(1);

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

            try {
                if (value.toString().contains("neighbourhood_group"))
                    return;
                else {

                    String[] mapperKeyValue = new String[0];
                    mapperKeyValue = value.toString().split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");

                    //if the text line contains more or less than 16 columns text line will be ignored as it may be corrupted
                    if(mapperKeyValue.length == 16) {
                        mapperText.set(mapperKeyValue[4].trim());
                    }
                    context.write(mapperText, one);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static class RentalsGroupReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
        private IntWritable result = new IntWritable();

        public void reduce(Text key, Iterable<IntWritable> values, Context context)
                throws IOException, InterruptedException {
            int sum = 0;
            for (IntWritable val : values) {
                sum += val.get();
            }

            result.set(sum);
            context.write(key, result);

        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        if (otherArgs.length != 2) {
            System.err.println("Usage: WordCount <in> <out>");
            System.exit(2);
        }

        //Setting up hadoop map reduce job
        Job job = Job.getInstance(conf, "word count");
        job.setJarByClass(RentalsForNeighbourhoodGroup.class);
        job.setMapperClass(RentalsGroupMapper.class);
        job.setCombinerClass(RentalsGroupReducer.class);
        job.setReducerClass(RentalsGroupReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(job, new Path(otherArgs[0]));
        FileOutputFormat.setOutputPath(job, new Path(otherArgs[1]));
        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}